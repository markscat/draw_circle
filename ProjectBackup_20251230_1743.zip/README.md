# draw_circle
教學局<br>
這個程式有兩個頁簽：<br>

Circle Tab<br>
**用電腦畫一個圓可以用哪些演算法來計算<br>
*Wave Tab<br>
**觀察圓和sin,cos,以及諧波的數學意義<br>


